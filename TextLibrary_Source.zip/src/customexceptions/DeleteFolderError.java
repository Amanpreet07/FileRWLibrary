package customexceptions;

public class DeleteFolderError extends Exception {
    public DeleteFolderError(String s) {
    super(s);
    }  
}
