package customexceptions;

public class FileNotFound extends Exception {

    public FileNotFound(String s) {
        super(s);
    }
}
