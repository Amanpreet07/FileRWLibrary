package customexceptions;

public class LineLimit extends Exception{

    public LineLimit(String s) {
    super(s);
    }
    
}
