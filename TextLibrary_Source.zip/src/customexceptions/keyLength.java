package customexceptions;

public class keyLength extends Exception{

    public keyLength(String s) {
    super(s);
    }
    
}
